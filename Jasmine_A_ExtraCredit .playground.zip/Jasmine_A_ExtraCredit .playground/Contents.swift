import UIKit

//Circle
var myCircle = { (radius:Double) -> Double in
    return 3.14 * (radius * radius)
}

var areaCircle = myCircle(3.2)
print (areaCircle)

//Triangle
var myTriangle = { ( base: Double, height:Double) -> Double in
    return (base * height) * 0.5
}

var area_triangle = myTriangle (5, 8)
print(area_triangle)
    
//Square

var Square = { (Length:Double, Width:Double) -> Double in
    return (Length * Width)
}
 var areaSquare = Square ( 5, 5)
print(areaSquare)

//Rectangle

var Rectangle = { ( Width:Double, Height: Double) -> Double in
    return ( Width * Height )
    
}

var AreaRectangle = Rectangle (12,5)
print (AreaRectangle)

//Parallelograms

var Parallelogram = {( Base:Double, VHeight:Double) -> Double in
    return (Base * VHeight)
    
}
var AreaParallelogram = Parallelogram (9, 17)
print (AreaParallelogram)

//Ellipse
var Ellipse = { (a: Double, b:Double ) -> Double in
    return 3.14 * (a * b)
}

var AreaEllipse = Ellipse(12,3)
print(AreaEllipse)

//Trapezoid
var Trapezoid = { (area:Double, base:Double, height: Double) -> Double in
    return 0.5 * (area + base) * height
}
var AreaTrapezoid = Trapezoid(5,8,4)
print(AreaTrapezoid)


//Sector
var Sector = { (radius:Double)-> Double in
    return 0.5 * (radius) * 3.14 / 180
    
}

var AreaSector = Sector(8)
print (AreaSector)











